package com.example.dreammovie;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.dreammovie.adapter.adapter_list;
import com.example.dreammovie.database.DatabaseManager;
import com.example.dreammovie.model.model_movie;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = "MainActivity";
    public Button btnInput, btnExit, btnDeleteItem, btnClearAll;
    public ListView listMovie;
    public TextView emptyView;

    private final ArrayList<model_movie> dataMovie = new ArrayList<>();
    private adapter_list adapterMovie;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // Initialize views
            listMovie = findViewById(R.id.list_movie);
            btnInput = findViewById(R.id.add_item);
            btnExit = findViewById(R.id.exit);
            btnDeleteItem = findViewById(R.id.delete_item);
            Button btnUpdateItem = findViewById(R.id.update_item);
            btnClearAll = findViewById(R.id.clear_all);
            emptyView = findViewById(R.id.empty_view);

            Log.d(TAG, "Views initialized successfully");

            // Initialize adapter and set to ListView
            adapterMovie = new adapter_list(dataMovie, this);
            adapterMovie.setOnItemCheckedChangeListener(() -> {
                DeleteButtonVisibility();
                UpdateButtonVisibility(btnUpdateItem);
            });
            listMovie.setAdapter(adapterMovie);
            listMovie.setEmptyView(emptyView);

            Log.d(TAG, "Adapter set to ListView successfully");

            // Retrieve data from the database
            fetchData();

            // Set click listener for Add Item button
            btnInput.setOnClickListener(view -> {
                Log.d(TAG, "Add Item button clicked");
                Intent intent = new Intent(MainActivity.this, InputActivity.class);
                startActivity(intent);
            });

            // Set click listener for Exit button
            btnExit.setOnClickListener(view -> {
                Log.d(TAG, "Exit button clicked");
                finishAffinity();
                System.exit(0);
            });

            // Handle data from Intent
            handleIntentData(getIntent());

            // Set click listener for Delete Item button
            btnDeleteItem.setOnClickListener(view -> {
                DatabaseManager dbManager = DatabaseManager.getInstance(MainActivity.this);
                for (int i = adapterMovie.getCount() - 1; i >= 0; i--) {
                    model_movie movie = (model_movie) adapterMovie.getItem(i);
                    if (movie.isSelected()) {
                        dataMovie.remove(movie);
                        dbManager.open();
                        dbManager.deleteMovie(movie.getId());
                        dbManager.close();
                    }
                }
                adapterMovie.notifyDataSetChanged();
                DeleteButtonVisibility();
                UpdateButtonVisibility(btnUpdateItem);
                Log.d(TAG, "Selected items deleted and adapter notified");
            });

            // Set click listener for Clear All button
            btnClearAll.setOnClickListener(view -> {
                DatabaseManager dbManager = DatabaseManager.getInstance(MainActivity.this);
                dbManager.open();
                dbManager.deleteAllMovies();
                dbManager.close();

                dataMovie.clear();
                adapterMovie.notifyDataSetChanged();
                DeleteButtonVisibility();
                UpdateButtonVisibility(btnUpdateItem);
                Log.d(TAG, "All items cleared and adapter notified");
            });

            // Set click listener for Update Item button
            btnUpdateItem.setOnClickListener(view -> {
                for (int i = 0; i < adapterMovie.getCount(); i++) {
                    model_movie movie = (model_movie) adapterMovie.getItem(i);
                    if (movie.isSelected()) {
                        Intent intent = new Intent(MainActivity.this, UpdateActivity.class);
                        intent.putExtra("id", movie.getId());
                        intent.putExtra("judul", movie.getJudulMovie());
                        intent.putExtra("genre", movie.getGenreMovie());
                        intent.putExtra("tahun", movie.getTahunTerbit());
                        startActivity(intent);
                        break;
                    }
                }
                Log.d(TAG, "Update Item button clicked");
            });

            // Check visibility of Delete and Update buttons on start
            DeleteButtonVisibility();
            UpdateButtonVisibility(btnUpdateItem);

        } catch (Exception e) {
            Log.e(TAG, "Error during onCreate: ", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Retrieve data from the database when activity resumes
        fetchData();
    }

    private void fetchData() {
        try {
            DatabaseManager dbManager = DatabaseManager.getInstance(MainActivity.this);
            dbManager.open();
            ArrayList<model_movie> movies = dbManager.getAllMovies();
            dbManager.close();
            dataMovie.clear();
            dataMovie.addAll(movies);
            adapterMovie.notifyDataSetChanged();
            Log.d(TAG, "Data fetched from database and adapter notified");
        } catch (Exception e) {
            Log.e(TAG, "Error fetching data: ", e);
        }
    }

    // Metode untuk menangani data dari Intent
    private void handleIntentData(Intent intent) {
        try {
            if (intent != null && intent.getExtras() != null) {
                String judul = intent.getStringExtra("judul");
                String genre = intent.getStringExtra("genre");
                String tahun = intent.getStringExtra("tahun");

                Log.d(TAG, "Received data - Judul: " + judul + ", Genre: " + genre + ", Tahun: " + tahun);

                if (judul != null && genre != null && tahun != null) {
                    DatabaseManager dbManager = DatabaseManager.getInstance(MainActivity.this);
                    dbManager.open();
                    ArrayList<model_movie> movies = dbManager.getAllMovies();
                    dbManager.close();
                    dataMovie.clear();
                    dataMovie.addAll(movies);
                    adapterMovie.notifyDataSetChanged();
                    DeleteButtonVisibility();
                    UpdateButtonVisibility(findViewById(R.id.update_item));
                    Log.d(TAG, "New data received and adapter notified");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during handleIntentData: ", e);
        }
    }

    // Metode untuk memperbarui visibilitas tombol Update
    private void UpdateButtonVisibility(Button btnUpdateItem) {
        int selectedItemCount = 0;
        for (int i = 0; i < adapterMovie.getCount(); i++) {
            model_movie movie = (model_movie) adapterMovie.getItem(i);
            if (movie.isSelected()) {
                selectedItemCount++;
            }
        }
        if (selectedItemCount == 1) {
            btnUpdateItem.setVisibility(View.VISIBLE);
        } else {
            btnUpdateItem.setVisibility(View.GONE);
        }
    }

    // Metode untuk memperbarui visibilitas tombol Delete
    private void DeleteButtonVisibility() {
        if (adapterMovie.anyItemSelected()) {
            btnDeleteItem.setVisibility(View.VISIBLE);
        } else {
            btnDeleteItem.setVisibility(View.GONE);
        }
    }
}