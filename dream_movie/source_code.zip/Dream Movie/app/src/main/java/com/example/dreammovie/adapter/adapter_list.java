package com.example.dreammovie.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.dreammovie.R;
import com.example.dreammovie.model.model_movie;

import java.util.ArrayList;

public class adapter_list extends BaseAdapter {

    private final LayoutInflater inflater;
    private final ArrayList<model_movie> movies;
    private OnItemCheckedChangeListener onItemCheckedChangeListener;

    public adapter_list(ArrayList<model_movie> movie_data, Context context) {
        this.movies = movie_data;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int position) {
        return movies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return movies.get(position).getId();
    }

    private static class ViewHolder {
        TextView m_judul;
        TextView m_genre;
        TextView m_tahun;
        CheckBox checkBox;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.view_list, parent, false);
            holder = new ViewHolder();
            holder.m_judul = convertView.findViewById(R.id.text_judul);
            holder.m_genre = convertView.findViewById(R.id.text_genre);
            holder.m_tahun = convertView.findViewById(R.id.text_tahun);
            holder.checkBox = convertView.findViewById(R.id.checkbox_select);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        model_movie movie = movies.get(position);
        holder.m_judul.setText(movie.getJudulMovie());
        holder.m_genre.setText(movie.getGenreMovie());
        holder.m_tahun.setText(movie.getTahunTerbit());
        holder.checkBox.setChecked(movie.isSelected());

        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            movie.setSelected(isChecked);
            if (onItemCheckedChangeListener != null) {
                onItemCheckedChangeListener.onItemCheckedChanged();
            }
        });

        return convertView;
    }

    public boolean anyItemSelected() {
        for (model_movie movie : movies) {
            if (movie.isSelected()) {
                return true;
            }
        }
        return false;
    }

    public void setOnItemCheckedChangeListener(OnItemCheckedChangeListener listener) {
        this.onItemCheckedChangeListener = listener;
    }

    public interface OnItemCheckedChangeListener {
        void onItemCheckedChanged();
    }
}
