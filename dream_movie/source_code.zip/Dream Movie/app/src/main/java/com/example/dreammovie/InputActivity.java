package com.example.dreammovie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import com.example.dreammovie.database.DatabaseManager;

public class InputActivity extends AppCompatActivity {
    private EditText inputJudul, inputGenre, inputTahun;
    private Button btnSubmit, btnReset, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        // Initialize views
        inputJudul = findViewById(R.id.inputJudul);
        inputGenre = findViewById(R.id.inputGenre);
        inputTahun = findViewById(R.id.inputTahun);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnReset = findViewById(R.id.reset);
        btnBack = findViewById(R.id.back);

        // Set click listener for Submit button
        btnSubmit.setOnClickListener(view -> {
            String judul = inputJudul.getText().toString();
            String genre = inputGenre.getText().toString();
            String tahun = inputTahun.getText().toString();

            DatabaseManager dbManager = DatabaseManager.getInstance(InputActivity.this);
            dbManager.open();
            dbManager.insertMovie(judul, genre, tahun);
            dbManager.close();

            Intent intent = new Intent(InputActivity.this, MainActivity.class);
            intent.putExtra("judul", judul);
            intent.putExtra("genre", genre);
            intent.putExtra("tahun", tahun);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });



        // Set click listener for Reset button
        btnReset.setOnClickListener(view -> {
            inputJudul.setText("");
            inputGenre.setText("");
            inputTahun.setText("");
        });

        // Set click listener for Back button
        btnBack.setOnClickListener(view -> {
            finish();
        });
    }
}
