package com.example.dreammovie;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import com.example.dreammovie.database.DatabaseManager;
import com.example.dreammovie.model.model_movie;

public class UpdateActivity extends AppCompatActivity {
    private EditText inputJudul, inputGenre, inputTahun;
    private Button btnSubmit, btnReset, btnBack;

    private int movieId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // Initialize views
        inputJudul = findViewById(R.id.inputJudul);
        inputGenre = findViewById(R.id.inputGenre);
        inputTahun = findViewById(R.id.inputTahun);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnReset = findViewById(R.id.reset);
        btnBack = findViewById(R.id.back);

        // Retrieve movie details from Intent
        Intent intent = getIntent();
        movieId = intent.getIntExtra("id", -1);
        String judul = intent.getStringExtra("judul");
        String genre = intent.getStringExtra("genre");
        String tahun = intent.getStringExtra("tahun");

        // Populate the fields with movie details
        inputJudul.setText(judul);
        inputGenre.setText(genre);
        inputTahun.setText(tahun);

        // Set click listener for Submit button
        btnSubmit.setOnClickListener(view -> {
            String updatedJudul = inputJudul.getText().toString();
            String updatedGenre = inputGenre.getText().toString();
            String updatedTahun = inputTahun.getText().toString();

            model_movie movie = new model_movie(movieId, updatedJudul, updatedGenre, updatedTahun);

            DatabaseManager dbManager = DatabaseManager.getInstance(UpdateActivity.this);
            dbManager.open();
            dbManager.updateMovie(movie);
            dbManager.close();

            Intent resultIntent = new Intent(UpdateActivity.this, MainActivity.class);
            resultIntent.putExtra("judul", updatedJudul);
            resultIntent.putExtra("genre", updatedGenre);
            resultIntent.putExtra("tahun", updatedTahun);
            resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(resultIntent);
        });

        // Set click listener for Reset button
        btnReset.setOnClickListener(view -> {
            inputJudul.setText(judul);
            inputGenre.setText(genre);
            inputTahun.setText(tahun);
        });

        // Set click listener for Back button
        btnBack.setOnClickListener(view -> {
            finish();
        });
    }
}
