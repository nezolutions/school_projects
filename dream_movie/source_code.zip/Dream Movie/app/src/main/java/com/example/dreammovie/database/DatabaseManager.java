package com.example.dreammovie.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.dreammovie.model.model_movie;

import java.util.ArrayList;

public class DatabaseManager {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase database;
    private static DatabaseManager instance;

    private DatabaseManager(Context context) {
        this.openHelper = new DatabaseHelper(context);
    }

    public static synchronized DatabaseManager getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseManager(context);
        }
        return instance;
    }

    public void open() {
        this.database = openHelper.getWritableDatabase();
    }

    public void close() {
        if (database != null) {
            this.database.close();
        }
    }

    public long insertMovie(String judul, String genre, String tahun) {
        ContentValues values = new ContentValues();
        values.put("judul_film", judul);
        values.put("genre_film", genre);
        values.put("tahun_terbit", tahun);
        return database.insert("tb_movie", null, values);
    }

    public ArrayList<model_movie> getAllMovies() {
        ArrayList<model_movie> movieList = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM tb_movie", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String judul = cursor.getString(1);
                String genre = cursor.getString(2);
                String tahun = cursor.getString(3);
                movieList.add(new model_movie(id, judul, genre, tahun));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return movieList;
    }

    public void deleteMovie(int id) {
        database.delete("tb_movie", "id = ?", new String[]{String.valueOf(id)});
    }

    public void deleteAllMovies() {
        database.delete("tb_movie", null, null);
    }

    public void updateMovie(model_movie movie) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("judul_film", movie.getJudulMovie());
        contentValues.put("genre_film", movie.getGenreMovie());
        contentValues.put("tahun_terbit", movie.getTahunTerbit());

        String whereClause = "id = ?";
        String[] whereArgs = { String.valueOf(movie.getId()) };

        database.update("tb_movie", contentValues, whereClause, whereArgs);
    }
}
