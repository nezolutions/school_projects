package com.example.dreammovie.model;

public class model_movie {
    private int id;
    private String judulMovie;
    private String genreMovie;
    private String tahunTerbit;
    private boolean isSelected;

    public model_movie(int id, String judul, String genre, String tahun) {
        this.id = id;
        this.judulMovie = judul;
        this.genreMovie = genre;
        this.tahunTerbit = tahun;
        this.isSelected = false;
    }

    // Constructor without id for new movies
    public model_movie(String judul, String genre, String tahun) {
        this.judulMovie = judul;
        this.genreMovie = genre;
        this.tahunTerbit = tahun;
        this.isSelected = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJudulMovie() {
        return judulMovie;
    }

    public void setJudulMovie(String judulMovie) {
        this.judulMovie = judulMovie;
    }

    public String getGenreMovie() {
        return genreMovie;
    }

    public void setGenreMovie(String genreMovie) {
        this.genreMovie = genreMovie;
    }

    public String getTahunTerbit() {
        return tahunTerbit;
    }

    public void setTahunTerbit(String tahunTerbit) {
        this.tahunTerbit = tahunTerbit;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
